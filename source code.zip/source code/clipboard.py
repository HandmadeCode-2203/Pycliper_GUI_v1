import pyperclip as pyclip
import keyboard
import time
import tkinter as tk
from tkinter import messagebox
import threading

content1 = ""
content2 = ""
content3 = ""
content4 = ""
content5 = ""
content6 = ""
content7 = ""

def clipper_engine():
    while True:
        if keyboard.is_pressed("Ctrl+C"):
            content = pyclip.paste()
            global content1
            global content2
            global content3
            global content4
            global content5
            global content6
            global content7
            print("content=" + content)
            label.config(text=content)
            content7 = content6
            content6 = content5
            content5 = content4
            content4 = content3
            content3 = content2
            content2 = content1
            content1 =content
            label.config(text=content1[:10] + "....")
            label1.config(text=content2[:10] + "....")
            label2.config(text=content3[:10] + "....")
            label3.config(text=content4[:10] + "....")
            label4.config(text=content5[:10] + "....")
            label5.config(text=content6[:10] + "....")
            label6.config(text=content7[:10] + "....")
            time.sleep(0.1)
            keyboard.wait("Ctrl+C")

thread = threading.Thread(target=clipper_engine, daemon=True)
thread.start()

root = tk.Tk()
root.title("pycliper_GUI")
root.geometry("300x400")
root.resizable(False,False)

num = 0
def front_on_off():
    global num
    if num == 0:
        root.attributes("-topmost", True)
        front.config(text="手前に表示しない")
        num = 1
    else:
        root.attributes("-topmost", False)
        front.config(text="常時手前に表示")
        num = 0
def copy():
    pyclip.copy(content1)
def copy1():
    pyclip.copy(content2)
def copy2():
    pyclip.copy(content3)
def copy3():
    pyclip.copy(content4)
def copy4():
    pyclip.copy(content5)
def copy5():
    pyclip.copy(content6)
def copy6():
    pyclip.copy(content7)

frame = tk.Frame(root)

front = tk.Button(frame,text="",command=front_on_off)
front.config(text="常時手前に表示")
front.pack(padx=5)
frame.pack(side="top")

frame1 = tk.Frame(root)
label = tk.Label(frame1,text="")
label.pack(side="left",padx=5,pady=10)

button = tk.Button(frame1,text="copy",command=copy)
button.pack(side="right",padx=5,pady=10)
frame1.pack()

frame2 = tk.Frame(root)
label1 = tk.Label(frame2,text="")
label1.pack(side="left",padx=5,pady=10)

button1 = tk.Button(frame2,text="copy",command=copy1)
button1.pack(side="right",padx=5,pady=10)
frame2.pack()

frame3 = tk.Frame(root)
label2 = tk.Label(frame3,text="")
label2.pack(side="left",padx=5,pady=10)

button2 = tk.Button(frame3,text="copy",command=copy2)
button2.pack(side="right",padx=5,pady=10)

frame3.pack()

frame4 = tk.Frame(root)

label3 = tk.Label(frame4,text="")
label3.pack(side="left",padx=5,pady=10)

button3 = tk.Button(frame4,text="copy",command=copy3)
button3.pack(side="right",padx=5,pady=10)
frame4.pack()

frame5 = tk.Frame(root)
label4 = tk.Label(frame5,text="")
label4.pack(side="left",padx=5,pady=10)

button4 = tk.Button(frame5,text="copy",command=copy4)
button4.pack(side="right",padx=5,pady=10)
frame5.pack()

frame6 = tk.Frame(root)
label5 = tk.Label(frame6,text="")
label5.pack(side="left",padx=5,pady=10)
button5 = tk.Button(frame6,text="copy",command=copy5)
button5.pack(side="right",padx=5,pady=10)
frame6.pack()

frame7 = tk.Frame(root)
label6 = tk.Label(frame7,text="")
label6.pack(side="left",padx=5,pady=10)
button6 = tk.Button(frame7,text="copy",command=copy6)
button6.pack(side="right",padx=5,pady=10)
frame7.pack()

root.mainloop()